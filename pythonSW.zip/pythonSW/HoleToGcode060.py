
# Hole to Gcode, a SW to import drill files from Kicad and made some GCODE about it

Version="0.60"



# Simple enough, just import everything from tkinter.
from tkinter import *
from tkinter.filedialog import askopenfilename , asksaveasfilename
from opt2 import TwoOPT
import json


# Here, we are creating our class, Window, and inheriting from the Frame
# class. Frame is a class from the tkinter module. (see Lib/tkinter/__init__)
class Window(Frame):

    # Define settings upon initialization. Here you can specify
    def __init__(self, master=None):
    
        # parameters that you want to send through the Frame class. 
        Frame.__init__(self, master)   

        #reference to the master widget, which is the tk window                 
        self.master = master

        #with that, we want to then run init_window, which doesn't yet exist
        self.init_window()
        
        self.init_variables()


    def init_variables(self):

        self.drlfile=[]

        self.gcodefile=[]
        
        self.filecoordlist=[]
        
        self.normalization={}  # keeps the min max parameters
        
        self.exclusionzone=[] # coordinates for the exclusuion zones rectangles list of [x,y,x1,y1]
        
        self.referencehole=[]  # coordinates of reference hole
        
        self.patharray=[] # list of sorted points for print
        
        self.checkboxes = {}
        
        self.outputgcode = [] # list of gcode for output
        
        self.snippetfilename =""
        
        self.startfilename =""
        
        self.gcodefilestart = []
        
        self.endfilename =""     
        
        self.drlfilename= ""   
        
        self.gcodefileend =[]

        self.transformation={"rotation":0 , "verticalflip":0 , "horizontalflip":0}

        self.pad=120


    #Creation of init_window
    def init_window(self):

        # changing the title of our master widget      
        self.master.title("Holes to Gcode ")

        # allowing the widget to take the full space of the root window
        self.pack(fill=BOTH, expand=True)

        # creating a menu instance -------------------------------------------
        menu = Menu(self.master)
        self.master.config(menu=menu)

        # create the file object)
        file = Menu(menu)

        # adds a command to the menu option, calling it exit, and the


        #added "file" to our menu
        menu.add_cascade(label="File", menu=file)
        
        file.add_command(label = 'Open Drill File', command = self.loadanddraw)
        file.add_command(label = 'Open Gcode snippet', command = self.loadgcodesni)        
        file.add_command(label = 'Open Gcode Start', command = self.loadgcodestart)
        file.add_command(label = 'Open Gcode End', command = self.loadgcodeend)
        file.add_separator()

        file.add_command(label = 'Open Configutation File', command = self.loadconfigvariables)
        file.add_command(label = 'Save Configuration File', command = self.saveconfigvariables)  


        
        # command it runs on event is client_exit
        file.add_command(label="Exit", command=self.client_exit)

        # create the file object)
        edit = Menu(menu)

        # adds a command to the menu option, calling it exit, and the
        # command it runs on event is client_exit
        edit.add_command(label = 'Draw', command = self.drawdata) 
        #added "file" to our menu
        menu.add_cascade(label="Edit", menu=edit)
        
        # Configure row and colums --------------------------------------------------------------------------------------------

        self.columnconfigure(0, weight=1) # wieght attribute make expandable        
        self.columnconfigure(5, weight=1) # wieght attribute make expandable
        self.columnconfigure(6, pad=7)
        self.rowconfigure(2, pad=7,weight=1)
        self.rowconfigure(4,weight=1)
        self.rowconfigure(6,weight=1)
        
        # create other objects

        lbl = Label(self, text="Snippet")
        lbl.grid(row=0, column=0, sticky=W, pady=4, padx=5)

        lbl3 = Label(self, text="Board")
        lbl3.grid(row=0, column=2, sticky=W, pady=4, padx=5)


        # Add text area --------------------------------------------------

        self.area = Text(self, width=20)
        self.area.grid(row=1, column=0, columnspan=2, rowspan=2,
            padx=5, sticky=E+W+S+N)

        lbl1 = Label(self, text="Start")
        lbl1.grid(row=3, column=0, sticky=W, pady=4, padx=5)

        self.areastart = Text(self, height=20, width=20 )
        self.areastart.grid(row=4, column=0, columnspan=2, rowspan=1,
            padx=5, sticky=E+W+S+N)
        
        lbl2 = Label(self, text="End")
        lbl2.grid(row=5, column=0, sticky=W, pady=4, padx=5)

            
        self.areaend = Text(self, width=20 , height=20)
        self.areaend.grid(row=6, column=0, columnspan=2, rowspan=1,
            padx=5, sticky=E+W+S+N)

        self.status = Label(self, text="Version "+Version)
        self.status.grid(row=7, column=0, sticky=W, pady=4, padx=5)
            
        # buttons for exclusion zone

        abtn = Button(self, text="Add exclusion Zone", command = self.activezone)
        abtn.grid(row=2, column=6)
        self.activezone=False

        rbtn = Button(self, text="clear exclusion Zones", command = self.clearzones)
        rbtn.grid(row=3, column=6)

        rbtn = Button(self, text="Rotate 90 clockwise", command = self.rotate90)
        rbtn.grid(row=4, column=6)

        rbtn = Button(self, text="Vertical Flip", command = self.vflip)
        rbtn.grid(row=5, column=6)

        rbtn = Button(self, text="Horizontal Flip", command = self.hflip)
        rbtn.grid(row=6, column=6)

        # bottom  buttons

        obtn = Button(self, text="Calculate path", command = self.runsalesman)
        obtn.grid(row=7, column=2)

        obtn = Button(self, text="Create Gcode", command = self.creategcode)
        obtn.grid(row=7, column=3)
  
        # Checkbox attempo ------------------------------------

        self.mb=  Menubutton(self, text="ExcludeDiameters", relief=RAISED )
        self.mb.grid(row=1, column=6)
        self.mb.menu  =  Menu ( self.mb, tearoff = 0 )
        self.mb["menu"]  =  self.mb.menu        

        
        # Create our canvas (blue background)    ------------------------------------------------------------------
        self.canvas = Canvas(self, bg="green")
        self.canvas.grid(row=1, column=2, columnspan=4, rowspan=6, padx=5, sticky=E+W+S+N)
        self.canvas.bind("<Configure>", self.redraw)
        # bind mouse buttons to canvas
        self.drawn = None
        self.shape = None
        self.start=None
        self.canvas.bind('<ButtonPress-1>', self.onStart) 
        self.canvas.bind('<ButtonRelease-1>', self.onRelease)
        self.canvas.bind('<B1-Motion>',     self.onGrow)  
        #canvas.bind('<Double-1>',      self.onClear) 
        #canvas.bind('<ButtonPress-3>', self.onMove) 
        
    def runsalesman(self):
        if self.filecoordlist:
            self.patharray=[]
            # create array with only selected
            xydata=[]
            for coords in self.filecoordlist:
                if coords[3]:
                    xy=[coords[0],coords[1]]
                    xydata.append(xy)
            t = TwoOPT(xydata)
            t.run()
            
            #print(t.outputtour)
            
            # find the index of teh reference hole
            index1=xydata.index(self.referencehole)
            indexref=t.outputtour.index(index1+1)
            
            
            print (" index 1 " ,  index1  ,"index ref ",  indexref)
            size=len(t.outputtour)
            for i in range(size):
                j=(i+indexref) % size
                self.patharray.append(xydata[t.outputtour[j]-1])


            self.drawdata()   

    def creategcode(self):
        if self.patharray:
            self.outputgcode =[]
             # start file
            for line in self.gcodefilestart:
                self.outputgcode.append(line) 
 
            
            # first snippet is included assuming that the first part of the Gcode bring is in the reference position
            for line in self.gcodefile:
                self.outputgcode.append(line)            
            
            
            # get path array data
            x0=self.patharray[0][0]
            y0=self.patharray[0][1]
            for i in range(1,len(self.patharray)):
                x=self.patharray[i][0]
                y=self.patharray[i][1]
                dx=x-x0
                dy=y-y0
                dx=self.inchtomm(dx)
                dy=self.inchtomm(dy)                
                # gcode string:  G0 X0.8 Z1.5
                Cmd="G0"
                X="X"+"{:.4f}".format(dx)
                Y="Y"+"{:.4f}".format(dy)
                line=Cmd+" "+X+" "+Y+"\n"
                x0=x
                y0=y
                cm1="; START: Go to relative position P " + str(i) + " \n"                
                self.outputgcode.append(cm1)
                self.outputgcode.append(line)
                cm2="; END -------------------------------------  \n"              
                self.outputgcode.append(cm2)
                for line in self.gcodefile:
                    self.outputgcode.append(line)
            
            # End file
            print(self.gcodefileend)
            for line in self.gcodefileend:
                self.outputgcode.append(line) 
            
            self.savelisttofile(self.outputgcode, ".gcode")
            
            
   
    def savelisttofile(self, datalist,exte):
        # Open and return file path
        filestype = [("Gcode", "*.gcode"),("Drill files", "*.drl"),("All Files","*.*")] 
        file_path = asksaveasfilename(filetypes = filestype, defaultextension = filestype) 
        with open(file_path, 'w') as f:
            for item in datalist:
                f.write(item)

    def saveconfigvariables(self):
        # Open and return file path
        filestype = [("Gcode", "*.json"),("All Files","*.*")] 
        file_path = asksaveasfilename(filetypes = filestype, defaultextension = filestype) 
        
        
        # prepare the variables
        ceckboxsave={}
        for cb in self.checkboxes:
            ceckboxsave[cb]= self.checkboxes[cb].get()        
        
        bigvar={}
        bigvar["1"]=self.exclusionzone
        bigvar["2"]=ceckboxsave
        bigvar["3"]=self.snippetfilename
        bigvar["4"]=self.startfilename
        bigvar["5"]=self.endfilename
        bigvar["6"]=self.drlfilename
        bigvar["7"]=self.transformation
        
        with open(file_path, 'w') as f:
  
            json.dump(bigvar, f,indent=0)
                    
                    
    def loadconfigvariables(self):

        # set all the data to zero

        self.init_variables()

        # Open and return file path
        filestype = [("Gcode", "*.json"),("All Files","*.*")] 
   
        name=""
        datafile=[]
        name = askopenfilename(initialdir="C:/",
                           filetypes =filestype,
                           title = "Choose a file."
                           )
        print (name)
        # Using try in case user types in unknown file or closes without choosing a file.
        try:
            with open(name, 'r') as f:
                bigvar=json.load(f)
        except:
            name=""
            print("No file exists")	  
            return name
            
            
        self.exclusionzone=bigvar["1"]
        ceckboxsave=bigvar["2"]
        self.snippetfilename=bigvar["3"]
        self.startfilename=bigvar["4"]
        self.endfilename=bigvar["5"]        
        self.drlfilename=bigvar["6"]
        self.transformation=bigvar["7"]
        
        # apply the saved config

        self.drlfile , name =self.OpenFileName(self.drlfilename)
        
        if name!="":
            self.parsefile()
            self.createdropdwon()
            
            for cb in self.checkboxes:
                if ceckboxsave[cb]:
                    self.checkboxes[cb].set(1)
            

            self.calcnormalizedata()
            self.findreferencehole()
            self.drawdata()
            
        self.area.delete('1.0', END)
        self.gcodefile , name = self.OpenFileName(self.snippetfilename)
        if name!="":
            self.listtotextarea(self.gcodefile)

        print(" Start File NAme ", self.startfilename)
        self.areastart.delete('1.0', END)
        self.gcodefilestart , name = self.OpenFileName(self.startfilename)
        for row in self.gcodefilestart:
            self.areastart.insert(END, row)

        self.areaend.delete('1.0', END)
        self.gcodefileend , name = self.OpenFileName(self.endfilename)
        for row in self.gcodefileend:
            self.areaend.insert(END, row)
            
        self.status["text"]="Configuration Loaded"

                  
        self.applyexclusion()
        return name
        

  

   
        
    def inchtomm(self, value):
        mm=value*25.4
        return mm
        
        
    def activezone(self):
        if self.filecoordlist:        
            self.activezone=True
            print("activated")

    def clearzones(self):
        self.exclusionzone=[]
        self.applyexclusion()

    def rotate90(self):
        self.applyTransform(90, 0, 0)

    def vflip(self):
        self.applyTransform(0, 1, 0)

    def hflip(self):
        self.applyTransform(0, 0, 1)


    def applyTransform(self, rotation, vflip, hflip):
        print(" Start Transformation")
        # clear exclusion zone
        self.exclusionzone=[]
        self.applyexclusion()
        #clear the patharray (salesman path)
        self.patharray=[]
        # rotate coordinates
        self.CoordTransform(rotation, vflip, hflip)
        self.calcnormalizedata()
        self.findreferencehole()
        self.drawdata()
        print (self.transformation)



    def onRelease(self, event):
        if self.activezone:
            #coords=[self.start.x, self.start.y, event.x, event.y]
            # put in the right order
            coords=[0,0,0,0]
            if self.start.x < event.x:
                coords[0]=self.start.x
                coords[2]=event.x
            else:
                coords[2]=self.start.x
                coords[0]=event.x               
            if self.start.y < event.y:
                coords[1]=self.start.y
                coords[3]=event.y
            else:
                coords[3]=self.start.y
                coords[1]=event.y 

            print("end" , coords)
            self.denormalizezone(coords)
            print("denom" , coords)
            self.exclusionzone.append(coords)
            self.applyexclusion()            
            self.activezone=False
                
    def onStart(self, event):
        if self.activezone:
            print("start")            
            self.shape = self.canvas.create_rectangle
            self.start = event
            self.drawn = None
    def onGrow(self, event):  
        if self.activezone:                       
            canvas = event.widget
            if self.drawn: canvas.delete(self.drawn)
            objectId = self.shape(self.start.x, self.start.y, event.x, event.y)
            self.drawn = objectId     
               
        
    def redraw(self, event):
        self.drawdata()


    
    def createdropdwon(self):        
        # remove checkboix in case already existing
        self.mb.menu.delete(0,'end')
        
        # Checkbox attempo ------------------------------------
        self.checkboxes = {} # dictionary to store all the IntVars
        for name in self.drilltools:
            var = IntVar()
            self.mb.menu.add_checkbutton(label=name+" :"+str(self.drilltools[name]), variable=var, command=self.checktoggle)
            self.checkboxes[name] = var # add IntVar to the dictionary

    def checktoggle(self):
        print ("toggle")
        self.applyexclusion()
                
    def applyexclusion(self):
        print ("exclude")
        # clear previpous exclusiosns
        for coord in self.filecoordlist:
            coord[3]=1
        # exclusions due to hole diameter
        for cb in self.checkboxes:
            if self.checkboxes[cb].get() == True:
                print ( cb   , " True ")
                d=self.drilltools[cb]
                for coord in self.filecoordlist:
                    if coord[2]==d:
                        coord[3]=0
        # exclusions due to exclusion zones
        for rt in self.exclusionzone:
            print(" rectangle ", rt)
            x0=rt[0]
            y0=rt[1]
            x1=rt[2]
            y1=rt[3]
            for coord in self.filecoordlist:
                if (coord[0]>x0) and (coord[0]<x1) and (coord[1]<y0) and (coord[1]>y1):
                    print(" found " , coord)
                    coord[3]=0
        
        self.findreferencehole()
        self.drawdata()        
        
    def loadanddraw(self):
        self.drlfile , self.drlfilename =self.OpenFile("*.drl")
        self.parsefile()
        #self.printtotextarea(self.drilltools)
        self.createdropdwon()
        self.calcnormalizedata()
        self.findreferencehole()
        self.drawdata()
        
    def loadgcodesni(self):
        self.area.delete('1.0', END)
        self.gcodefile , self.snippetfilename =self.OpenFile("*.gcode")
        self.listtotextarea(self.gcodefile)


    def loadgcodestart(self):
        self.areastart.delete('1.0', END)
        self.gcodefilestart , self.startfilename =self.OpenFile("*.gcode")
        for row in self.gcodefilestart:
            self.areastart.insert(END, row)

    def loadgcodeend(self):
        self.areaend.delete('1.0', END)
        self.gcodefileend , self.endfilename =self.OpenFile("*.gcode")
        for row in self.gcodefileend :
            self.areaend.insert(END, row)

                

    def OpenFileName(self, name):
        datafile=[]
        try:
            with open(name,'r') as f:
                datafile = f.readlines()
            
        except:
            name=""
            print("No file exists")	
        
        return datafile , name

        
        
    def OpenFile(self, exte="*.txt"):
        name=""
        datafile=[]
        name = askopenfilename(initialdir="C:/",
                           filetypes =(("Text File", exte),("All Files","*.*")),
                           title = "Choose a file."
                           )
        print (name)
        # Using try in case user types in unknown file or closes without choosing a file.
        try:
            with open(name,'r') as f:
                datafile = f.readlines()
            
        except:
            name=""
            print("No file exists")	
        
        return datafile , name
        
    def printfile(self):
        for row in self.drlfile:
           print(row)

    def parsefile(self):
        self.drilltools={}
        r=0
        for row in self.drlfile:
            if 	row[0]!=";":
                post=row.find("T")  # find tool definition
                if row[post]=="T":
                    posc=row.find("C")			   
                    if row[posc]=="C":
                        tmun=row[post:posc]
                        cnum=row[posc+1:]
                        self.drilltools[tmun]=float(cnum)
                    else:
                        for t in self.drilltools:
                            if t in row:
                                r=self.drilltools[t]
                   

			   			   
                posx=row.find("X")
                if row[posx]=="X":
                    posy=row.find("Y")
                    
                    if row[posy]=="Y":
                        xnum=row[posx+1:posy]
                        ynum=row[posy+1:]
                       
                        coord=[]
                        coord.append(float(xnum))
                        coord.append(float(ynum))
                        coord.append(r)
                        coord.append(1)
                        self.filecoordlist.append(coord)


        # apply transformation
        if self.filecoordlist:
            rotation=self.transformation.get("rotation",0)
            vflip=self.transformation.get("verticalflip",0)
            hflip=self.transformation.get("horizontalflip",0)
            self.transformation={"rotation":0 , "verticalflip":0 , "horizontalflip":0}
            self.CoordTransform(rotation, vflip, hflip)

        print(self.drilltools)


    def printtotextarea(self, texto):
        if texto:
            self.area.insert(END, texto)

    def listtotextarea(self, texto):
        if texto:
            for row in texto:
                self.area.insert(END, row)            


                   
    def calcnormalizedata(self):
        if self.filecoordlist:
            transpose=list(zip(*self.filecoordlist))

            x=transpose[0]
            minx=min(x)
            maxx=max(x)
            self.normalization["minx"]=minx
            self.normalization["manx"]=maxx

            y=transpose[1]
            miny=min(y)
            maxy=max(y)
            self.normalization["miny"]=miny
            self.normalization["many"]=maxy

    def CoordTransform(self, rotation , verticalflip, horizontalflip):
        if self.filecoordlist:
            
            if rotation>0: #clockwise
                for j in range(len(self.filecoordlist)):
                    x=self.filecoordlist[j][0]
                    y=self.filecoordlist[j][1]
                    if rotation==90:
                        self.filecoordlist[j][0]=y
                        self.filecoordlist[j][1]=-x
                        delta=90
                    if rotation==180:
                        self.filecoordlist[j][0]=-x
                        self.filecoordlist[j][1]=-y
                        delta=180
                    if rotation==270:
                        self.filecoordlist[j][0]=-y
                        self.filecoordlist[j][1]=x
                        delta=270
                self.transformation["rotation"]= (self.transformation["rotation"] + delta) % 360
                

            if verticalflip: 
                for j in range(len(self.filecoordlist)):
                    x=self.filecoordlist[j][0]
                    y=self.filecoordlist[j][1]
                    self.filecoordlist[j][0]=x
                    self.filecoordlist[j][1]=-y
                self.transformation["verticalflip"]= (self.transformation["verticalflip"] + 1) % 2

            if horizontalflip: 
                for j in range(len(self.filecoordlist)):
                    x=self.filecoordlist[j][0]
                    y=self.filecoordlist[j][1]
                    self.filecoordlist[j][0]=-x
                    self.filecoordlist[j][1]=y
                self.transformation["horizontalflip"]= (self.transformation["horizontalflip"] + 1) % 2



    def findreferencehole(self): 
        if self.filecoordlist and self.normalization:
            self.referencehole=[] 
            
            minx=self.normalization["minx"]
            miny=self.normalization["miny"]

            mindist=100000000     
            px=0
            py=0  
            
            for coords in self.filecoordlist:
                if coords[3]:
                    dist=abs(coords[0]-minx)+abs(coords[1]-miny)
                    if dist<mindist:
                        mindist=dist
                        px=coords[0]
                        py=coords[1]
        
            self.referencehole.append(px) 
            self.referencehole.append(py) 




    def denormalizezone(self, coords): # rectangle exclusion zone denormalization
        if self.normalization:
            
            # pad
            pad=self.pad
            # get canvas size
            framex=self.canvas.winfo_width()-pad
            framey=self.canvas.winfo_height()-pad
            
            minx=self.normalization["minx"]
            maxx=self.normalization["manx"]
            miny=self.normalization["miny"]
            maxy=self.normalization["many"]
                        
            if (maxx-minx)/(maxy-miny)>framex/framey:
                multiplier=framex/(maxx-minx)
            else:            
                multiplier=framey/(maxy-miny)   

            coords[0], coords[1] = self.xyCoordToCanvasInv(coords[0],coords[1],multiplier,pad)
            coords[2], coords[3] = self.xyCoordToCanvasInv(coords[2],coords[3],multiplier,pad)
			
    def drawdata(self): 
        if self.filecoordlist:
            self.canvas.delete("all")
            self.drawdatalist(self.filecoordlist,self.exclusionzone,self.referencehole)    


    def xyCoordToCanvas(self,x,y,multiplier,pad):
        minx=self.normalization["minx"]
        maxx=self.normalization["manx"]
        miny=self.normalization["miny"]
        maxy=self.normalization["many"]
        x1=(x-minx)*multiplier+pad/2
        y1=(maxy-y)*multiplier+pad/2
        return x1,y1

    def xyCoordToCanvasInv(self,x,y,multiplier,pad):
        minx=self.normalization["minx"]
        maxx=self.normalization["manx"]
        miny=self.normalization["miny"]
        maxy=self.normalization["many"]
        x1=(x-pad/2)/multiplier+minx
        y1=-(y-pad/2)/multiplier+maxy
        return x1,y1




    def drawdatalist(self, coordlist , rectcoordlist, referencehole):
        # pad
        pad=self.pad
        # get canvas size
        framex=self.canvas.winfo_width()-pad
        framey=self.canvas.winfo_height()-pad

        # normalize
        minx=self.normalization["minx"]
        maxx=self.normalization["manx"]
        miny=self.normalization["miny"]
        maxy=self.normalization["many"]



        
        if (maxx-minx)/(maxy-miny)>framex/framey:
            multiplier=framex/(maxx-minx)
        else:            
            multiplier=framey/(maxy-miny)   



        for j in range(len(coordlist)):
            x,y=self.xyCoordToCanvas(coordlist[j][0],coordlist[j][1],multiplier,pad)
            d=(coordlist[j][2])*multiplier        
            self.create_circle(x,y,d,outline="", fill="white" )
            if coordlist[j][3]:
                self.create_cross(x,y,8, width=3 )  
                
        for j in range(len(rectcoordlist)):
            x,y=self.xyCoordToCanvas(rectcoordlist[j][0],rectcoordlist[j][1],multiplier,pad)     
            x1,y1=self.xyCoordToCanvas(rectcoordlist[j][2],rectcoordlist[j][3],multiplier,pad)
            self.create_rectangle(x,y,x1,y1)  
                

        # draw axes

        # X axis
        x0=(pad/4)
        y0=(maxy-miny)*multiplier+pad/2+pad/4
        x1=(maxx-minx)*multiplier+pad/2
        y1=y0                
        self.canvas.create_line(x0, y0, x1, y1, fill="red", width=3)
        self.create_arrow(x1, y1, 16 ,  "x", fill="red" , width=3)
        self.create_cross(x1-24, y1+12, 12, fill="black" , width=3)

        # y axis
        x0=(pad/4)
        y0=(pad/2)  
        x1=x0
        y1=(maxy-miny)*multiplier+pad/2+pad/4         
        self.canvas.create_line(x0, y0, x1, y1, fill="red", width=3)
        self.create_arrow(x0, y0, 16 ,  "y", fill="red" , width=3)


        # draw reference hole
        x,y=self.xyCoordToCanvas(referencehole[0],referencehole[1],multiplier,pad) 
        # outline='#f11', fill='#1f1', width=2
        self.create_circle(x,y,20, outline="red" , fill="" , width=8)
        
        
        # draw print path
        if self.patharray:
            x,y=self.xyCoordToCanvas(self.patharray[0][0],self.patharray[0][1],multiplier,pad) 
 
            for xy in self.patharray:
                x1,y1=self.xyCoordToCanvas(xy[0],xy[1],multiplier,pad) 
                self.canvas.create_line(x, y, x1, y1, fill="blue", width=2)
                x=x1
                y=y1

                
           
    def create_circle(self, x, y, d, outline="gray1" , fill="", width=1): #center coordinates, radius
        x0 = x - d/2
        y0 = y - d/2
        x1 = x + d/2
        y1 = y + d/2
        self.canvas.create_oval(x0, y0, x1, y1, outline=outline , fill=fill, width=width)

    def create_rectangle(self, x0, y0, x1, y1, outline="gray1" , fill="", width=1): 
        self.canvas.create_rectangle(x0, y0, x1, y1, outline=outline , fill=fill, width=width)

    def create_cross(self, x, y, d, fill="gray1" , width=1): 
        x0 = x - d/2
        y0 = y - d/2
        x1 = x + d/2+1
        y1 = y + d/2+1
        self.canvas.create_line(x0, y0, x1, y1, fill=fill, width=width)
        self.canvas.create_line(x0, y1, x1, y0, fill=fill, width=width)
            
    def create_arrow(self, x, y, d , dir, fill="gray1" , width=1): 
        if dir == "x":
            x0 = x - d+1
            y0 = y - d/2-1
            x1 = x - d+1
            y1 = y + d/2+1
        elif dir=="y":
            x0 = x - d/2-1
            y0 = y + d-1
            x1 = x + d/2+1
            y1 = y + d-1

        self.canvas.create_line(x0, y0, x, y, fill=fill, width=width)
        self.canvas.create_line(x1, y1, x, y, fill=fill, width=width)

    def client_exit(self):
        exit()

        
# root window created. Here, that would be the only window, but
# you can later have windows within windows.
root = Tk()

root.geometry("800x600")


#creation of an instance
app = Window(root)

#mainloop 
root.mainloop() 
